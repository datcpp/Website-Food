function showNotification() {
    // Hiển thị thông báo
    var notification = document.getElementById('notification');
    notification.style.display = 'block';
  
    // Ẩn thông báo sau 5 giây
    setTimeout(function () {
      notification.style.display = 'none';
    }, 5000);
  }
  